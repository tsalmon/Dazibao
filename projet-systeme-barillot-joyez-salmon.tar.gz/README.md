Dépendance:
- GTK 2.0

Pour compiler:

~ make

Pour éxécuter:

~ ./dazibao fichierdazibao.dzb
